<?php

require_once __DIR__ . '/classes/Receita.php';
require_once __DIR__ . '/classes/Despesa.php';

require_once __DIR__ . '/database/conexao.php';
require_once __DIR__ . '/database/TransacaoRepo.php';

$repo = new TransacaoRepo($pdo);

$tipo = $_POST['tipo'];
$valor = (float) $_POST['valor'];
$data = $_POST['data'];
$descricao = $_POST['descricao'];

try {
    if ($tipo === 'receita') {
        $transacao = new Receita($id, $data, $valor, $descricao);
        $repo->adicionarReceita($transacao);
    } else {
        $transacao = new Despesa($id, $data, $valor, $descricao);
        $repo->adicionarDespesa($transacao);
    }
} catch (Exception $e) {
    header("Location: index.php?erro=" . urlencode($e->getMessage()));
    exit;
}

header("Location: index.php");
exit;

?>
