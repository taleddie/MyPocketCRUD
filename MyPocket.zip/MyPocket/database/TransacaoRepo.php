<?php

require_once __DIR__ . '/classes/Receita.php';
require_once __DIR__ . '/classes/Despesa.php';

class TransacaoRepo {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    // C - CREATE: receita
    public function adicionarReceita(Receita $receita): void {
        $this->inserir('receita', $receita);
    }

        // C - CREATE: despesa
    public function adicionarDespesa(Despesa $despesa): void {
    if ($despesa->getValor() > $this->calcularSaldo()) {
        throw new Exception("Saldo insuficiente.");
        }
        $this->inserir('despesa', $despesa);
    }

    // método auxiliar: o INSERT em si, reaproveitado pelos dois métodos acima
    private function inserir(string $tipo, Transacao $transacao): void {
        $stmt = $this->pdo->prepare(
            "INSERT INTO transacoes (tipo, valor, data, descricao) VALUES (:tipo, :valor, :data, :descricao)"
        ); // prepara a query com marcadores nomeados (evita SQL injection)

        $stmt->execute([
            'tipo' => $tipo,                     // 'receita' ou 'despesa'
            'valor' => $transacao->getValor(),   // valor guardado no objeto Transacao
            'data' => $transacao->getData(),     // data guardada no objeto
            'descricao' => $transacao->getDescricao(), // descrição guardada no objeto
        ]); // executa o INSERT de fato, substituindo os marcadores pelos valores
    }

    // R - READ (todas, mais recentes primeiro) — usado no index.php pro extrato
    public function listarTodas(): array {
        $stmt = $this->pdo->query("SELECT * FROM transacoes ORDER BY data DESC, id DESC"); // busca tudo, já ordenado
        $linhas = $stmt->fetchAll(PDO::FETCH_ASSOC); // traz o resultado como array associativo

        return array_map([$this, 'hidratar'], $linhas); // transforma cada linha crua em objeto Receita/Despesa
    }

    // R - READ (uma única) — usado no editar.php pra preencher o formulário
    public function buscarPorId(int $id): ?Transacao {
        $stmt = $this->pdo->prepare("SELECT * FROM transacoes WHERE id = :id"); // busca por id
        $stmt->execute(['id' => $id]); // executa passando o id
        $linha = $stmt->fetch(PDO::FETCH_ASSOC); // pega só uma linha (ou false, se não achar)

        return $linha ? $this->hidratar($linha) : null; // se achou, vira objeto; se não, retorna null
    }

    // U - UPDATE — usado no editar.php quando o form de edição é enviado
    public function atualizar(int $id, string $tipo, float $valor, string $data, string $descricao): void {
        $stmt = $this->pdo->prepare(
            "UPDATE transacoes SET tipo = :tipo, valor = :valor, data = :data, descricao = :descricao WHERE id = :id"
        ); // prepara o UPDATE, mudando todos os campos daquele id

        $stmt->execute([
            'tipo' => $tipo,
            'valor' => $valor,
            'data' => $data,
            'descricao' => $descricao,
            'id' => $id, // define QUAL linha vai ser alterada
        ]); // executa o UPDATE
    }

    // D - DELETE — usado no delete.php
    public function deletar(int $id): void {
        $stmt = $this->pdo->prepare("DELETE FROM transacoes WHERE id = :id"); // prepara o DELETE por id
        $stmt->execute(['id' => $id]); // executa, apagando a linha
    }

    // calcula o saldo direto no banco (substitui o $carteira->getSaldo() do original)
    public function calcularSaldo(): float {
        $stmt = $this->pdo->query(
            "SELECT COALESCE(SUM(CASE WHEN tipo = 'receita' THEN valor ELSE -valor END), 0) AS saldo FROM transacoes"
        ); // soma receitas e subtrai despesas tudo dentro do próprio SQL
        return (float) $stmt->fetch(PDO::FETCH_ASSOC)['saldo']; // pega o resultado da soma e converte pra float
    }

    // transforma uma linha do banco (array) num objeto Receita ou Despesa
    private function hidratar(array $linha): Transacao {
        if ($linha['tipo'] === 'receita') {
            // reconstrói o objeto Receita com os dados vindos do banco, incluindo o id
            return new Receita($linha['data'], (float) $linha['valor'], $linha['descricao'], (int) $linha['id']);
        }
        // se não for receita, é despesa
        return new Despesa($linha['data'], (float) $linha['valor'], $linha['descricao'], (int) $linha['id']);
    }
}

